#config file containing credentials for rds mysql instance
db_username = "username"
db_password = "password"
db_name = "ExampleDB" 
